# 纵维立方有线控制终端（Windows）

通过 USB 串口控制 Anycubic 全系 FDM 打印机（Marlin 及其衍生固件）。

界面布局与 Linux 版一致：左列「状态 / 温度 / 风扇 / G-code 发送」，
右列「移动 / SD 卡」，底部「控制台」。

---

## 一、打包成 EXE（推荐）

双击 **`build_exe.bat`**，等 1～2 分钟。

脚本会自动完成：
1. 检查 Python
2. 安装 `pyinstaller` + `pyserial`
3. 用内置图标 `anycubic.ico` 打包成单文件 exe
4. 打开 `dist` 文件夹

产物：**`dist\anycubic-ctl.exe`**

这个 exe **已内置 Python 运行时、tkinter 和 pyserial**，
可以直接拷到没装 Python 的电脑上双击运行，不需要任何环境。

> 想改名字直接重命名 exe 即可，不影响使用。

---

## 二、不打包，直接运行

1. 安装 Python 3.8+（勾选 `Add Python to PATH`）
2. 双击 **`run.bat`**
   - 首次运行会自动安装依赖

或命令行：

```
pip install pyserial
python anycubic_ctl.py
```

---

## 三、支持的机型

连接后自动读取 `M115` 识别机型，按机型启用/隐藏热床控件：

| 机型 | 热床 | 喷嘴上限 |
|---|---|---|
| Mega Zero | 无（自动隐藏） | 260℃ |
| Mega Zero 2.0 / Mega S / Chiron / Kobra 系列 | 100℃ | 260℃ |
| Vyper | 110℃ | 260℃ |
| 其它 Marlin 设备 | 110℃（通用档） | 260℃ |

## 四、功能

- **温度**：预设预热、自定义设定、一键降温（关加热 + 风扇全速 + 50℃ 自动停风）
- **风扇**：滑条无级调速 + 关/30/50/100% 快捷键
- **移动**：方向键盘、步长 0.1/1/10/50mm、分组归零、解锁电机、限位状态
- **手动调平**：自动回原点 → 五点（四角 + 中心）→ Z 轴微调
- **SD 卡**：浏览、打印、暂停、继续、停止
- **电脑文件**：选 G-code 直接流式发送（ok 流控，不撑爆打印机缓冲）
- **控制台**：任意 G-code 收发
- **自动连接**：启动后自动连上次用的串口
- **窗口记忆**：记住尺寸和位置

## 五、Windows 串口

- 打印机接上后设备管理器里出现 `USB-SERIAL CH340 (COMx)`
- 程序下拉框自动列出所有 COM 口，无需手填
- 端口不出现时装 CH340 驱动：https://www.wch.cn/downloads/CH341SER_EXE.html

## 六、重要：关于打印中断

程序打开串口时**不驱动 DTR/RTS**，避免 CH340 的 DTR 接到 MCU 复位脚
导致打印机重启、打断正在进行的打印。

**但其它串口工具（Pronterface、Cura 的 Monitor 等）没有这个保护** ——
打印过程中用它们连接，很可能直接把打印按掉。本程序是安全的。

## 七、配置文件

- Windows：`%APPDATA%\anycubic-ctl\config.json`
- Linux/macOS：`~/.config/anycubic-ctl.json`
