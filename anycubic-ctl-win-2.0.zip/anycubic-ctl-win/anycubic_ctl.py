#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""纵维立方有线控制终端 — 跨平台版（Windows / Linux / macOS）

GUI 使用 Python 标准库 tkinter，串口使用 pyserial。
支持 Anycubic 全系 FDM 打印机（Marlin 及其衍生固件）：
Mega Zero / Mega Zero 2.0 / Mega S / Chiron / Kobra 系列 / Vyper 等。

运行依赖：pyserial（pip install pyserial）
"""
import json
import os
import queue
import re
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    sys.exit("缺少依赖 pyserial，请先执行：pip install pyserial")

VERSION = "2.0"
BAUD = 115200

# ─────────── 机型档案 ───────────
PROFILES = [
    {"id": "mz",      "name": "Mega Zero",       "match": r"mega\s*zero(?!\s*2)",       "bed": False, "bmax": 0,   "nmax": 260, "size": (220, 220, 250)},
    {"id": "mz2",     "name": "Mega Zero 2.0",   "match": r"mega\s*zero\s*2",           "bed": True,  "bmax": 100, "nmax": 260, "size": (220, 220, 250)},
    {"id": "megas",   "name": "Mega S",          "match": r"mega\s*s\b",                "bed": True,  "bmax": 100, "nmax": 260, "size": (210, 210, 205)},
    {"id": "chiron",  "name": "Chiron",          "match": r"chiron",                    "bed": True,  "bmax": 100, "nmax": 260, "size": (400, 400, 450)},
    {"id": "vyper",   "name": "Vyper",           "match": r"vyper",                     "bed": True,  "bmax": 110, "nmax": 260, "size": (245, 245, 260)},
    {"id": "kobra",   "name": "Kobra",           "match": r"kobra(?!\s*(go|plus|max))", "bed": True,  "bmax": 100, "nmax": 260, "size": (220, 220, 250)},
    {"id": "kobrago", "name": "Kobra Go",        "match": r"kobra\s*go",                "bed": True,  "bmax": 100, "nmax": 260, "size": (220, 220, 250)},
    {"id": "kobrapl", "name": "Kobra Plus",      "match": r"kobra\s*plus",              "bed": True,  "bmax": 100, "nmax": 260, "size": (300, 300, 350)},
    {"id": "kobramx", "name": "Kobra Max",       "match": r"kobra\s*max",               "bed": True,  "bmax": 100, "nmax": 260, "size": (400, 400, 450)},
    {"id": "gen",     "name": "通用 Marlin 设备", "match": r".*",                        "bed": True,  "bmax": 110, "nmax": 260, "size": (220, 220, 250)},
]


def detect_profile(text):
    for p in PROFILES:
        if re.search(p["match"], text, re.I):
            return p
    return PROFILES[-1]


# ─────────── 配置 ───────────
def conf_path():
    if os.name == "nt":
        base = os.environ.get("APPDATA", os.path.expanduser("~"))
        return os.path.join(base, "anycubic-ctl", "config.json")
    return os.path.expanduser("~/.config/anycubic-ctl.json")


CONF = conf_path()


def load_conf():
    try:
        with open(CONF, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_conf(data):
    try:
        os.makedirs(os.path.dirname(CONF), exist_ok=True)
        with open(CONF, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
    except Exception:
        pass


# ─────────── 串口 ───────────
class Port:
    """打开串口时不驱动 DTR/RTS，避免 CH340 板子被意外复位"""

    def __init__(self, dev):
        self.s = serial.Serial()
        self.s.port = dev
        self.s.baudrate = BAUD
        self.s.timeout = 0
        self.s.dsrdtr = False
        self.s.rtscts = False
        try:
            self.s.dtr = False
            self.s.rts = False
        except Exception:
            pass
        self.s.open()
        try:
            self.s.dtr = False
            self.s.rts = False
        except Exception:
            pass
        self.buf = b""

    def write(self, text):
        self.s.write(text.encode())

    def readlines(self):
        out = []
        try:
            n = self.s.in_waiting
            if n:
                self.buf += self.s.read(n)
        except Exception:
            return out
        while b"\n" in self.buf:
            line, self.buf = self.buf.split(b"\n", 1)
            out.append(line.decode(errors="replace").strip())
        return out

    def close(self):
        try:
            self.s.close()
        except Exception:
            pass


class Worker(threading.Thread):
    def __init__(self, dev, cmdq, outq):
        super().__init__(daemon=True)
        self.dev, self.cmdq, self.outq = dev, cmdq, outq
        self.alive = True
        self.stream = None
        self.sidx = 0
        self.waiting_ok = False

    def start_stream(self, lines):
        self.stream, self.sidx, self.waiting_ok = lines, 0, False

    def stop_stream(self):
        self.stream = None

    def run(self):
        try:
            port = Port(self.dev)
            self.outq.put(("^", "已连接 " + self.dev))
        except Exception as e:
            self.outq.put(("!", "连接失败: " + str(e)))
            return

        while self.alive:
            try:
                while True:
                    cmd = self.cmdq.get_nowait()
                    if cmd is None:
                        self.alive = False
                        break
                    port.write(cmd + "\n")
                    self.outq.put((">", cmd))
            except queue.Empty:
                pass

            if self.stream is not None and not self.waiting_ok:
                if self.sidx >= len(self.stream):
                    self.outq.put(("^", "文件发送完毕"))
                    self.stream = None
                else:
                    line = self.stream[self.sidx].strip()
                    self.sidx += 1
                    if line and not line.startswith(";"):
                        port.write(line + "\n")
                        self.waiting_ok = True
                        if self.sidx % 100 == 0:
                            self.outq.put(("^", "已发送 %d/%d 行" % (self.sidx, len(self.stream))))

            for line in port.readlines():
                low = line.lower()
                if low.startswith("ok"):
                    self.waiting_ok = False
                elif low.startswith("resend"):
                    self.sidx = max(0, self.sidx - 1)
                    self.waiting_ok = False
                self.outq.put(("<", line))
            time.sleep(0.01)
        port.close()


# ─────────── 调平向导 ───────────
class LevelWindow(tk.Toplevel):
    def __init__(self, master, send, size):
        super().__init__(master)
        self.title("手动调平")
        self.send = send
        self.w, self.d = size[0], size[1]
        m = 25
        self.pts = [("左前角", m, m), ("右前角", self.w - m, m),
                    ("右后角", self.w - m, self.d - m), ("左后角", m, self.d - m),
                    ("中心", self.w // 2, self.d // 2)]
        self.i = -1
        self.resizable(False, False)

        self.lbl = ttk.Label(self, text="点「开始」回原点，然后逐个角调节", wraplength=420)
        self.lbl.pack(anchor="w", padx=14, pady=(14, 4))
        self.hint = ttk.Label(self, text="", wraplength=420, foreground="#666")
        self.hint.pack(anchor="w", padx=14, pady=(0, 10))

        row = ttk.Frame(self)
        row.pack(fill="x", padx=14, pady=4)
        self.btn_start = ttk.Button(row, text="开始", command=self.start)
        self.btn_start.pack(side="left", expand=True, fill="x", padx=3)
        self.btn_next = ttk.Button(row, text="下一个角", command=self.next_point, state="disabled")
        self.btn_next.pack(side="left", expand=True, fill="x", padx=3)

        row2 = ttk.Frame(self)
        row2.pack(fill="x", padx=14, pady=4)
        for label, dz in (("Z +0.05", 0.05), ("Z -0.05", -0.05), ("Z +0.5", 0.5), ("Z -0.5", -0.5)):
            ttk.Button(row2, text=label, command=lambda dz=dz: self.nudge(dz)).pack(
                side="left", expand=True, fill="x", padx=3)

        ttk.Button(self, text="结束并抬高", command=self.finish).pack(fill="x", padx=14, pady=(8, 14))

    def start(self):
        self.send("G28")
        self.send("G1 Z5 F600")
        self.i = -1
        self.next_point()
        self.btn_start.config(state="disabled")
        self.btn_next.config(state="normal")

    def next_point(self):
        self.i += 1
        if self.i >= len(self.pts):
            self.lbl.config(text="五点已完成。建议再走一轮确认各角一致。")
            return
        name, x, y = self.pts[self.i]
        self.send("G1 Z5 F600")
        self.send("G1 X%d Y%d F3000" % (x, y))
        self.send("G1 Z0.2 F300")
        self.lbl.config(text="[%d/5] %s  X%d Y%d" % (self.i + 1, name, x, y))
        self.hint.config(text="把 A4 纸放在喷嘴下，转动该角手轮，直到纸能抽出但有轻微阻力。")

    def nudge(self, dz):
        self.send("G91")
        self.send("G1 Z%+.2f F60" % dz)
        self.send("G90")

    def finish(self):
        self.send("G1 Z10 F600")
        self.destroy()


# ─────────── 主窗口 ───────────
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("纵维立方有线控制终端 v" + VERSION)
        self.geometry("980x760")
        self.minsize(560, 520)
        self.conf = load_conf()
        geo = self.conf.get("geometry", {})
        if geo.get("w") and geo.get("h"):
            self.geometry("%dx%d" % (int(geo["w"]), int(geo["h"])))
        if geo.get("max"):
            try:
                self.state("zoomed" if os.name == "nt" else "normal")
            except Exception:
                pass

        self.cmdq, self.outq = queue.Queue(), queue.Queue()
        self.worker = None
        self.profile = PROFILES[0]
        self.file_lines = None
        self._cooling = False
        self._noz = None
        self.ports = []

        self._build_top()
        self._build_body()
        self._build_console()
        self._layout_cards(True)
        self.bind("<Configure>", self._on_resize)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        self.after(150, self.pump)
        self.after(2000, self.poll)
        self.after(900, self.autoconnect)
        self.apply_profile(PROFILES[0], detected=False)

    # ── 顶栏 ──
    def _build_top(self):
        bar = ttk.Frame(self, padding=(10, 8))
        bar.pack(fill="x")
        ttk.Label(bar, text="串口").pack(side="left")
        self.port_var = tk.StringVar()
        self.port_box = ttk.Combobox(bar, textvariable=self.port_var, width=18, state="readonly")
        self.port_box.pack(side="left", padx=6)
        ttk.Button(bar, text="刷新", command=self.refresh_ports, width=6).pack(side="left")
        self.conn_btn = ttk.Button(bar, text="连接", command=self.toggle, width=8)
        self.conn_btn.pack(side="left", padx=8)
        self.auto_var = tk.BooleanVar(value=bool(self.conf.get("auto_connect", True)))
        ttk.Checkbutton(bar, text="自动连接", variable=self.auto_var).pack(side="left")
        self.model_var = tk.StringVar(value="未连接")
        ttk.Label(bar, textvariable=self.model_var).pack(side="right")

    def refresh_ports(self):
        ports = []
        for p in list_ports.comports():
            ports.append(p.device)
        self.ports = ports
        self.port_box["values"] = ports if ports else ["（未检测到串口）"]
        last = self.conf.get("port")
        if last in ports:
            self.port_var.set(last)
        elif ports:
            self.port_var.set(ports[0])
        else:
            self.port_var.set("（未检测到串口）")

    # ── 卡片 ──
    def card(self, parent, title):
        f = ttk.LabelFrame(parent, text=" " + title + " ", padding=8)
        return f

    def _build_body(self):
        self.body = ttk.Frame(self, padding=(10, 0))
        self.body.pack(fill="both", expand=True)
        self.body.columnconfigure(0, weight=1, uniform="col")
        self.body.columnconfigure(1, weight=1, uniform="col")

        # 状态
        self.f_status = self.card(self.body, "状态")
        self.lbl_noz = ttk.Label(self.f_status, text="喷嘴  --.- / 0 ℃", font=("", 12))
        self.lbl_noz.pack(anchor="w")
        self.lbl_bed = ttk.Label(self.f_status, text="热床  --.- / 0 ℃", font=("", 12))
        self.lbl_bed.pack(anchor="w")
        self.lbl_pos = ttk.Label(self.f_status, text="X --   Y --   Z --")
        self.lbl_pos.pack(anchor="w", pady=(4, 2))
        self.prg = ttk.Progressbar(self.f_status, maximum=100)
        self.prg.pack(fill="x", pady=4)
        self.lbl_job = ttk.Label(self.f_status, text="SD 空闲", foreground="#666")
        self.lbl_job.pack(anchor="w")

        # 温度
        self.f_temp = self.card(self.body, "温度")
        r = ttk.Frame(self.f_temp)
        r.pack(fill="x", pady=2)
        for label, t in (("PLA 200", 200), ("ABS 240", 240), ("PETG 230", 230)):
            ttk.Button(r, text=label, command=lambda t=t: self.send("M104 S%d" % t)).pack(
                side="left", expand=True, fill="x", padx=2)
        r2 = ttk.Frame(self.f_temp)
        r2.pack(fill="x", pady=2)
        ttk.Label(r2, text="喷嘴").pack(side="left")
        self.noz_spin = ttk.Spinbox(r2, from_=0, to=260, increment=5, width=6)
        self.noz_spin.set(200)
        self.noz_spin.pack(side="left", padx=4)
        ttk.Button(r2, text="设定", width=6,
                   command=lambda: self.send("M104 S%d" % int(float(self.noz_spin.get())))).pack(side="left", padx=2)
        ttk.Button(r2, text="降温", width=6, command=self.cooldown).pack(side="left", padx=2)

        self.bed_row = ttk.Frame(self.f_temp)
        self.bed_row.pack(fill="x", pady=2)
        ttk.Label(self.bed_row, text="热床").pack(side="left")
        self.bed_spin = ttk.Spinbox(self.bed_row, from_=0, to=110, increment=5, width=6)
        self.bed_spin.set(60)
        self.bed_spin.pack(side="left", padx=4)
        ttk.Button(self.bed_row, text="设定", width=6,
                   command=lambda: self.send("M140 S%d" % int(float(self.bed_spin.get())))).pack(side="left", padx=2)
        ttk.Button(self.bed_row, text="降温", width=6, command=self.cooldown).pack(side="left", padx=2)

        # 风扇
        self.f_fan = self.card(self.body, "风扇")
        self.fan_scale = ttk.Scale(self.f_fan, from_=0, to=100, command=self._fan_moved)
        self.fan_scale.pack(fill="x", pady=(4, 2))
        self.fan_lbl = ttk.Label(self.f_fan, text="0%")
        self.fan_lbl.pack(anchor="e")
        rf = ttk.Frame(self.f_fan)
        rf.pack(fill="x", pady=2)
        for label, pct in (("关", 0), ("30%", 30), ("50%", 50), ("100%", 100)):
            ttk.Button(rf, text=label, command=lambda p=pct: self.set_fan(p)).pack(
                side="left", expand=True, fill="x", padx=2)

        # G-code 发送
        self.f_file = self.card(self.body, "电脑上的 G-code")
        self.file_var = tk.StringVar(value="未选择文件")
        ttk.Label(self.f_file, textvariable=self.file_var, foreground="#666").pack(anchor="w")
        rf2 = ttk.Frame(self.f_file)
        rf2.pack(fill="x", pady=2)
        ttk.Button(rf2, text="选择…", command=self.pick_file).pack(side="left", expand=True, fill="x", padx=2)
        ttk.Button(rf2, text="发送并打印", command=self.stream_file).pack(side="left", expand=True, fill="x", padx=2)
        ttk.Button(rf2, text="中止", command=self.stop_stream).pack(side="left", expand=True, fill="x", padx=2)

        # 移动
        self.f_move = self.card(self.body, "移动")
        self.step_var = tk.StringVar(value="10")
        ttk.Combobox(self.f_move, textvariable=self.step_var, values=("0.1", "1", "10", "50"),
                     state="readonly", width=8).pack(fill="x", pady=(0, 6))

        pad = ttk.Frame(self.f_move)
        pad.pack(pady=2)
        grid = [("Y+", 1, 0), ("X-", 0, 1), ("⌂", 1, 1), ("X+", 2, 1), ("Y-", 1, 2)]
        for label, cx, cy in grid:
            if label == "⌂":
                cmd = lambda: self.send("G28")
            else:
                ax, sign = label[0], (1 if label[1] == "+" else -1)
                cmd = lambda a=ax, s=sign: self.jog(a, s)
            ttk.Button(pad, text=label, width=7, command=cmd).grid(row=cy, column=cx, padx=3, pady=3)

        zf = ttk.Frame(self.f_move)
        zf.pack(pady=(2, 6))
        ttk.Button(zf, text="Z-", width=12, command=lambda: self.jog("Z", -1)).pack(side="left", padx=3)
        ttk.Button(zf, text="Z+", width=12, command=lambda: self.jog("Z", 1)).pack(side="left", padx=3)

        rf3 = ttk.Frame(self.f_move)
        rf3.pack(fill="x", pady=1)
        for label, g in (("全部归零", "G28"), ("归零 X", "G28 X"), ("归零 Y", "G28 Y"), ("归零 Z", "G28 Z")):
            ttk.Button(rf3, text=label, command=lambda g=g: self.send(g)).pack(
                side="left", expand=True, fill="x", padx=2)
        rf4 = ttk.Frame(self.f_move)
        rf4.pack(fill="x", pady=1)
        for label, g in (("解锁电机", "M84"), ("限位状态", "M119")):
            ttk.Button(rf4, text=label, command=lambda g=g: self.send(g)).pack(
                side="left", expand=True, fill="x", padx=2)
        ttk.Button(self.f_move, text="手动调平…", command=self.open_level).pack(fill="x", pady=(4, 0))

        # SD 卡
        self.f_sd = self.card(self.body, "SD 卡")
        self.sd_tree = ttk.Treeview(self.f_sd, columns=("size",), height=6, show="tree headings")
        self.sd_tree.heading("#0", text="文件")
        self.sd_tree.heading("size", text="大小")
        self.sd_tree.column("#0", width=180)
        self.sd_tree.column("size", width=80, anchor="e")
        self.sd_tree.pack(fill="both", expand=True)
        self.sd_tree.bind("<Double-1>", lambda *a: self.start_print())
        rs = ttk.Frame(self.f_sd)
        rs.pack(fill="x", pady=(4, 0))
        for label, fn in (("刷新", lambda: self.send("M20")), ("打印", self.start_print),
                          ("暂停", lambda: self.send("M25")), ("继续", lambda: self.send("M24")),
                          ("停止", lambda: self.send("M524"))):
            ttk.Button(rs, text=label, command=fn, width=6).pack(side="left", expand=True, fill="x", padx=1)

    def _build_console(self):
        f = ttk.LabelFrame(self, text=" 控制台 ", padding=6)
        f.pack(fill="both", expand=True, padx=10, pady=(6, 10))
        self.log = tk.Text(f, height=8, wrap="none")
        self.log.pack(fill="both", expand=True)
        sb = ttk.Scrollbar(f, command=self.log.yview)
        self.log.config(yscrollcommand=sb.set)
        sb.place(relx=1.0, rely=0, relheight=0.85, anchor="ne")
        r = ttk.Frame(f)
        r.pack(fill="x", pady=(4, 0))
        self.entry = ttk.Entry(r)
        self.entry.pack(side="left", fill="x", expand=True)
        self.entry.bind("<Return>", lambda e: self.on_send())
        ttk.Button(r, text="发送", command=self.on_send, width=8).pack(side="left", padx=4)

    def _layout_cards(self, wide):
        """宽窗口两列，窄窗口单列"""
        if getattr(self, "_wide", None) == wide:
            return
        self._wide = wide
        for w in (self.f_status, self.f_temp, self.f_fan, self.f_file, self.f_move, self.f_sd):
            w.grid_forget()
        left = [self.f_status, self.f_temp, self.f_fan, self.f_file]
        right = [self.f_move, self.f_sd]
        if wide:
            for i, w in enumerate(left):
                w.grid(row=i, column=0, sticky="nsew", padx=(0, 6), pady=4)
            for i, w in enumerate(right):
                w.grid(row=i, column=1, sticky="nsew", padx=(6, 0), pady=4)
        else:
            for i, w in enumerate(left + right):
                w.grid(row=i, column=0, columnspan=2, sticky="nsew", pady=4)

    def _on_resize(self, event):
        if event.widget is not self:
            return
        self._layout_cards(event.width >= 760)

    # ── 连接 ──
    def toggle(self):
        if self.worker:
            self.worker.alive = False
            self.cmdq.put(None)
            self.worker = None
            self.conn_btn.config(text="连接")
            self.model_var.set("未连接")
            return
        dev = self.port_var.get()
        if not dev or dev.startswith("（"):
            self.append("!", "未检测到串口")
            return
        self.conf["port"] = dev
        save_conf(self.conf)
        self.worker = Worker(dev, self.cmdq, self.outq)
        self.worker.start()
        self.conn_btn.config(text="断开")
        self.after(1200, lambda: self.send("M115"))

    def autoconnect(self):
        if self.auto_var.get() and not self.worker and self.ports:
            self.append("^", "检测到 %s，自动连接…" % self.ports[0])
            self.port_var.set(self.ports[0])
            self.toggle()

    def send(self, gcode):
        if not self.worker:
            self.append("!", "未连接")
            return
        self.cmdq.put(gcode)

    def poll(self):
        if self.worker:
            self.send("M105")
            self.send("M114")
            self.send("M27")
        self.after(2000, self.poll)

    # ── 动作 ──
    def jog(self, axis, sign):
        step = float(self.step_var.get())
        self.send("G91")
        self.send("G1 %s%s F3000" % (axis, ("%+g" % (sign * step))))
        self.send("G90")

    def _fan_moved(self, _=None):
        pct = int(float(self.fan_scale.get()))
        self.fan_lbl.config(text="%d%%" % pct)

    def set_fan(self, pct):
        self.fan_scale.set(pct)
        self.fan_lbl.config(text="%d%%" % pct)
        self.send("M106 S%d" % round(pct * 255 / 100))

    def cooldown(self):
        self.send("M104 S0")
        if self.profile["bed"]:
            self.send("M140 S0")
        self.send("M106 S255")
        self.fan_scale.set(100)
        self.fan_lbl.config(text="100%")
        self._cooling = True
        self.append("^", "开始降温：加热已关闭，风扇全速；喷嘴低于 50℃ 后自动停风")

    def start_print(self):
        sel = self.sd_tree.selection()
        if not sel:
            self.append("!", "请先选中一个文件")
            return
        name = self.sd_tree.item(sel[0], "text")
        self.send("M23 " + name)
        self.send("M24")
        self.append("^", "开始打印 " + name)

    def pick_file(self):
        path = filedialog.askopenfilename(
            title="选择 G-code",
            filetypes=[("G-code", "*.gcode *.gco *.g *.GCO"), ("所有文件", "*.*")])
        if not path:
            return
        try:
            with open(path, errors="ignore") as f:
                self.file_lines = f.read().splitlines()
            self.file_var.set("%s   %d 行" % (os.path.basename(path), len(self.file_lines)))
        except Exception as e:
            self.file_var.set("读取失败: %s" % e)

    def stream_file(self):
        if not self.worker:
            self.append("!", "未连接")
            return
        if not self.file_lines:
            self.append("!", "未选择文件")
            return
        self.worker.start_stream(list(self.file_lines))
        self.append("^", "开始发送 %d 行（ok 流控）" % len(self.file_lines))

    def stop_stream(self):
        if self.worker:
            self.worker.stop_stream()
            self.append("!", "已中止发送")

    def open_level(self):
        if not self.worker:
            self.append("!", "未连接")
            return
        LevelWindow(self, self.send, self.profile["size"])

    def on_send(self):
        text = self.entry.get().strip()
        if text:
            self.send(text)
            self.entry.delete(0, "end")

    # ── 输出 ──
    def append(self, kind, text):
        self.log.insert("end", text + "\n")
        self.log.see("end")

    def pump(self):
        try:
            while True:
                kind, text = self.outq.get_nowait()
                self.append(kind, text)
                if kind == "<":
                    self.parse(text)
        except queue.Empty:
            pass
        self.after(150, self.pump)

    def parse(self, line):
        m = re.search(r"T:([\d.]+)\s*/\s*([\d.]+)", line)
        if m:
            self._noz = float(m.group(1))
            self.lbl_noz.config(text="喷嘴  %5.1f / %.0f ℃" % (self._noz, float(m.group(2))))
            if self._cooling and self._noz < 50:
                self._cooling = False
                self.send("M106 S0")
                self.fan_scale.set(0)
                self.fan_lbl.config(text="0%")
                self.append("^", "已降到 %.1f℃，风扇已自动停止" % self._noz)
        m = re.search(r"B:([\d.]+)\s*/\s*([\d.]+)", line)
        if m:
            self.lbl_bed.config(text="热床  %5.1f / %.0f ℃" % (float(m.group(1)), float(m.group(2))))
        m = re.search(r"X:(-?[\d.]+)\s*Y:(-?[\d.]+)\s*Z:(-?[\d.]+)", line)
        if m:
            self.lbl_pos.config(text="X %6.1f   Y %6.1f   Z %6.1f" %
                                     (float(m.group(1)), float(m.group(2)), float(m.group(3))))
        if "FIRMWARE_NAME" in line:
            self.apply_profile(detect_profile(line), detected=True)
        m = re.search(r"SD printing byte\s+(\d+)/(\d+)", line)
        if m:
            cur, tot = int(m.group(1)), int(m.group(2))
            self.prg["value"] = 100.0 * cur / tot if tot else 0
            self.lbl_job.config(text="打印中  %.2f / %.2f MB  (%.1f%%)" %
                                     (cur / 1048576, tot / 1048576, 100.0 * cur / tot if tot else 0))
        elif "Not SD printing" in line:
            self.prg["value"] = 0
            self.lbl_job.config(text="SD 空闲")
        elif line.startswith("Begin file list"):
            for i in self.sd_tree.get_children():
                self.sd_tree.delete(i)
        elif re.match(r"^[\w~.\- ]+\s+\d+$", line):
            name, size = line.rsplit(None, 1)
            self.sd_tree.insert("", "end", text=name, values=("%.2f MB" % (int(size) / 1048576),))

    def apply_profile(self, prof, detected):
        self.profile = prof
        self.model_var.set(("已识别: " if detected else "机型: ") + prof["name"])
        if prof["bed"]:
            self.bed_row.pack(fill="x", pady=2)
            self.lbl_bed.pack(anchor="w")
            self.bed_spin.config(to=prof["bmax"])
        else:
            self.bed_row.pack_forget()
            self.lbl_bed.pack_forget()
        self.noz_spin.config(to=prof["nmax"])
        if detected:
            self.append("^", "机型档案: %s" % prof["name"])

    # ── 退出保存 ──
    def on_close(self):
        geo = {"max": self.state() == "zoomed" if os.name == "nt" else False}
        if not geo["max"]:
            geo.update({"w": self.winfo_width(), "h": self.winfo_height(),
                        "x": self.winfo_x(), "y": self.winfo_y()})
        self.conf["geometry"] = geo
        self.conf["auto_connect"] = self.auto_var.get()
        save_conf(self.conf)
        if self.worker:
            self.worker.alive = False
            self.cmdq.put(None)
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
