@echo off
chcp 65001 >nul
title 打包 EXE — 纵维立方有线控制终端
cd /d "%~dp0"
setlocal

where python >nul 2>nul
if errorlevel 1 (
    echo.
    echo [错误] 未找到 Python
    echo 请安装 Python 3.8 或更高版本，安装时务必勾选 "Add Python to PATH"
    echo 下载: https://www.python.org/downloads/
    echo.
    pause
    exit /b 1
)

echo ===============================================
echo   纵维立方有线控制终端 — exe 打包
echo ===============================================
echo.

echo [1/4] 安装打包依赖 pyinstaller + pyserial ...
python -m pip install --upgrade pip >nul 2>&1
python -m pip install --upgrade pyinstaller pyserial
if errorlevel 1 (
    echo.
    echo [错误] 依赖安装失败，请检查网络或手动执行：
    echo     python -m pip install pyinstaller pyserial
    echo.
    pause
    exit /b 1
)

echo.
echo [2/4] 清理旧产物 ...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist anycubic-ctl.spec del /q anycubic-ctl.spec

echo.
echo [3/4] 开始打包（约 1-2 分钟，请勿关闭窗口）...
python -m PyInstaller --noconfirm --clean --onefile --windowed ^
    --name "anycubic-ctl" ^
    --icon "%~dp0anycubic.ico" ^
    "%~dp0anycubic_ctl.py"
if errorlevel 1 (
    echo.
    echo [错误] 打包失败，请把上面的报错信息发出来
    pause
    exit /b 1
)

echo.
echo [4/4] 完成
echo ===============================================
echo   产物: %~dp0dist\anycubic-ctl.exe
echo.
echo   该 exe 已内置 Python 运行时、tkinter 与 pyserial，
echo   可直接拷贝到没装 Python 的电脑上运行。
echo   想改名的话，重命名 exe 即可，不影响使用。
echo ===============================================
echo.
if exist "%~dp0dist" start "" explorer "%~dp0dist"
pause
