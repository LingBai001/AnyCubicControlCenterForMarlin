@echo off
chcp 65001 >nul
title 纵维立方有线控制终端
where python >nul 2>nul
if errorlevel 1 (
    echo.
    echo 未找到 Python。
    echo 请先安装 Python 3.8 或更高版本，安装时务必勾选 "Add Python to PATH"。
    echo 下载地址: https://www.python.org/downloads/
    echo.
    pause
    exit /b 1
)
python -c "import serial" >nul 2>nul
if errorlevel 1 (
    echo 首次运行，正在安装依赖 pyserial ...
    python -m pip install pyserial
    if errorlevel 1 (
        echo 依赖安装失败，请手动执行: python -m pip install pyserial
        pause
        exit /b 1
    )
)
start "" pythonw "%~dp0anycubic_ctl.py"
